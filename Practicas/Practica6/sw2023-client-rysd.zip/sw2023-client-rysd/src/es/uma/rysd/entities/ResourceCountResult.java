package es.uma.rysd.entities;

// Clase para obtener la respuesta ante una llamada al API del tipo http://swapi.dev/api/{recurso}/ 
// Solo usaremos en esta pr�ctica la cantidad de elmento del recurso solicitado que existe

public class ResourceCountResult {
	public Integer count;	
}

package es.uma.rysd.entities;

//Clase obtenida cuando se consulta por un veh�culo

public class Vehicle {
	public String name;
	public String model;
	public String vehicle_class;
	public String length;
	public String cost_in_credits;
	public String[] pilots;
}
